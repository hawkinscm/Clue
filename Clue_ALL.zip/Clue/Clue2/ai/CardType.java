package ai;

/**
 * This class...
 *
 * @author Aaron Kay
 */
public enum CardType {
  SUSPECT, WEAPON, ROOM
}
