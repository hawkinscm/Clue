
package jdd.graph;

import jdd.util.Test;

/**
 * Class for the maximum-flow algotihms.
 *
 * <p>NOTE: currently, we have no implementation for this one.
 * <br>If someone feels like coding the Ford-Fulkerson, please let us know :)
 */
public class MaximumFlow {


	// TODO:
	// public static void ford_fulkerson(Graph g, Node source, Node sink) {
	// }

	// -------------------------------------------
	/** testbench. do not call */
	public static void internal_test() {
		Test.start("MaximumFlow");
		Test.end();
	}

}
