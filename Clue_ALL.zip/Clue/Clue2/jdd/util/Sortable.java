
package jdd.util;

/** A sortable object */
public interface Sortable {
    boolean greater_than(Sortable s);
}
