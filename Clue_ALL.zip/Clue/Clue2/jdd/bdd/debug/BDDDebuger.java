
package jdd.bdd.debug;

/**
 * This class will report BDD statistics.
 *
 */

public interface BDDDebuger {
	void stop();
}

