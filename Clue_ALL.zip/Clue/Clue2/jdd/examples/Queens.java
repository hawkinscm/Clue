
package jdd.examples;

public interface Queens	{
	int getN();
	long getTime();
	boolean [] getOneSolution();
	double numberOfSolutions();
}
