
package jdd.examples;


/**
 * This is the third simple BDD example. It explains things you need to know
 * for working with BDD representation of sequential models such as state machines
 *
 * <p>
 * The comments in the code will guide you Thor creating a very simple
 * BDD Application
 */

// This is our class "Simple3", where we will put all the code for this simple example:
public class Simple3 {

	// since the example is so simple, we will put everything in the main function
	public static void main(String [] args) {


// TODO!!

	}
}
